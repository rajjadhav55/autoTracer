"""AutoTrace framework integrations."""
